using Microsoft.EntityFrameworkCore;
using TeacherStudentApp.Entities;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMemoryCache();
builder.Services.AddSession();


builder.Services.AddControllersWithViews();
builder.Services.AddDbContext<CoursesDbContext>(
        options => options.UseSqlServer(builder.Configuration.GetConnectionString("CoursesDb"))
    );

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.UseSession();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Course}/{action=Index}/{id?}");

app.Run();
