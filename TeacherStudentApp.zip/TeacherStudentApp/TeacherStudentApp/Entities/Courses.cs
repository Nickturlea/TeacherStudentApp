﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace TeacherStudentApp.Entities
{
    public class Courses
    {
        [Key]
        public int CourseId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Instructor is required")]
        public string Instructor { get; set; }

        [Required(ErrorMessage = "Start date is required")]
        public DateTime StartDate { get; set; }

        [Required(ErrorMessage = "Room number is required")]
        [RegularExpression(@"^\d[A-Z]\d{2}$", ErrorMessage = "Room number must be in the format: a single digit, a single capital letter, and 2 digits, e.g. 3G15")]
        public string RoomNumber { get; set; }

        public EnrollmentStatus Status { get; set; } = EnrollmentStatus.ConfirmationMessageNotSent;

        public ICollection<Student> Students { get; set; } = new List<Student>();

        [Display(Name = "Number Of Students")]
        public int NumberOfStudents
        {
            get { return Students.Count; }
            private set { }
        }
    }

    public enum EnrollmentStatus
    {
        ConfirmationMessageNotSent,
        ConfirmationMessageSent,
        EnrollmentConfirmed,
        EnrollmentDeclined
    }

    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string StudentName { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }
        public int CourseId { get; set; }
        public Courses Course { get; set; }

        public EnrollmentStatus Status { get; set; } = EnrollmentStatus.ConfirmationMessageNotSent;
    }
}
