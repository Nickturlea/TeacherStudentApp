﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Reflection.Emit;
using TeacherStudentApp.Entities;

namespace TeacherStudentApp.Entities
{
    public class CoursesDbContext : DbContext
    {
        public DbSet<Courses> CoursesDbSet { get; set; }
        public DbSet<Student> StudentsDbSet { get; set; }

        public CoursesDbContext(DbContextOptions<CoursesDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Courses>().HasData(
                new Courses { CourseId = 1, Name = "Science", Instructor = "Clark Kent", StartDate = new DateTime(2023, 1, 2), RoomNumber = "3G11" },
                new Courses { CourseId = 2, Name = "Math", Instructor = "Owen Michals", StartDate = new DateTime(2021, 1, 1), RoomNumber = "7A21" },
                new Courses { CourseId = 3, Name = "Art", Instructor = "Aba Links", StartDate = new DateTime(2023, 2, 12), RoomNumber = "9L16" }
            );

            modelBuilder.Entity<Student>().HasData(
                new Student { StudentId = 1, StudentName = "John King", Email = "nickturlea@gmail.com", CourseId = 1, Status = EnrollmentStatus.ConfirmationMessageNotSent },
                new Student { StudentId = 2, StudentName = "Jane Doe", Email = "doe@gmail@gmail.com", CourseId = 2, Status = EnrollmentStatus.ConfirmationMessageNotSent },
                new Student { StudentId = 3, StudentName = "Bob Smith", Email = "smith@gmail@gmail.com", CourseId = 3, Status = EnrollmentStatus.ConfirmationMessageNotSent }
            );
        }
    }
}
