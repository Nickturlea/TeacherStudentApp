﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TeacherStudentApp.Migrations
{
    /// <inheritdoc />
    public partial class inits : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "CoursesDbSet",
                columns: table => new
                {
                    CourseId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Instructor = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RoomNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false),
                    NumberOfStudents = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CoursesDbSet", x => x.CourseId);
                });

            migrationBuilder.CreateTable(
                name: "StudentsDbSet",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StudentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CourseId = table.Column<int>(type: "int", nullable: false),
                    Status = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_StudentsDbSet", x => x.StudentId);
                    table.ForeignKey(
                        name: "FK_StudentsDbSet_CoursesDbSet_CourseId",
                        column: x => x.CourseId,
                        principalTable: "CoursesDbSet",
                        principalColumn: "CourseId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "CoursesDbSet",
                columns: new[] { "CourseId", "Instructor", "Name", "NumberOfStudents", "RoomNumber", "StartDate", "Status" },
                values: new object[,]
                {
                    { 1, "Clark Kent", "Science", 0, "3G11", new DateTime(2023, 1, 2, 0, 0, 0, 0, DateTimeKind.Unspecified), 0 },
                    { 2, "Owen Michals", "Math", 0, "7A21", new DateTime(2021, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 0 },
                    { 3, "Aba Links", "Art", 0, "9L16", new DateTime(2023, 2, 12, 0, 0, 0, 0, DateTimeKind.Unspecified), 0 }
                });

            migrationBuilder.InsertData(
                table: "StudentsDbSet",
                columns: new[] { "StudentId", "CourseId", "Email", "Status", "StudentName" },
                values: new object[,]
                {
                    { 1, 1, "nickturlea@gmail.com", 0, "John King" },
                    { 2, 2, "doe@gmail@gmail.com", 0, "Jane Doe" },
                    { 3, 3, "smith@gmail@gmail.com", 0, "Bob Smith" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_StudentsDbSet_CourseId",
                table: "StudentsDbSet",
                column: "CourseId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "StudentsDbSet");

            migrationBuilder.DropTable(
                name: "CoursesDbSet");
        }
    }
}
