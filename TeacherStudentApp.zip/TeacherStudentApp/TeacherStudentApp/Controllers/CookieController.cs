﻿using System;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

public class CookieController : Controller
{
    public void UpdateCookieCount(string page)
    {
        int currentVisits = HttpContext.Session.GetInt32(page) ?? 0;
        currentVisits++;
        HttpContext.Session.SetInt32(page, currentVisits);

        if (HttpContext.Session.GetString("FirstVisit") == null)
        {
            // First visit
            DateTime currentDateTime = DateTime.Now;

            // Mark the first visit during session
            HttpContext.Session.SetString("FirstVisit", currentDateTime.ToString());
            ViewData["WelcomeMessage"] = $"Welcome to my teacher student management app! This is your first visit.";
        }
        else
        {
            // Returning visit during session
            DateTime firstVisittime = DateTime.Parse(HttpContext.Session.GetString("FirstVisit"));
            ViewData["WelcomeMessage"] = $"Welcome back! You first used this app on {firstVisittime}.";
        }
    }
}
