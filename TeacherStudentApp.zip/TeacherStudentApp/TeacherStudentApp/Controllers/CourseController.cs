﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using TeacherStudentApp.Entities;
using System.Net.Mail;
using System.Net;
using static TeacherStudentApp.Entities.Courses;

namespace TeacherStudentApp.Controllers
{
    public class CourseController : CookieController
    {
        private CoursesDbContext courses;
        public CourseController(CoursesDbContext course)
        {
            this.courses = course;
        }

        public IActionResult Index()
        {

            UpdateCookieCount("Index");
            return View();
        }

        public IActionResult Details()
        {
            UpdateCookieCount("Details");
            var coursesWithStudents = courses.CoursesDbSet.Include(c => c.Students).ToList();
            return View(coursesWithStudents);
        }


        [HttpGet]
        public IActionResult Add()
        {
            UpdateCookieCount("Add");
            return View(new Courses());
        }


        [HttpGet]
        public IActionResult Edit(int id)
        {
            UpdateCookieCount("Edit");

            var existingCourse = courses.CoursesDbSet.Find(id);

            if (existingCourse == null)
            {
                return NotFound();
            }
            return View(existingCourse);
        }

        [HttpGet]
        public IActionResult Manage(int id)
        {
            UpdateCookieCount("Manage");
            var courseWithStudents = courses.CoursesDbSet
                .Include(c => c.Students)
                .FirstOrDefault(c => c.CourseId == id);

            if (courseWithStudents == null)
            {
                return NotFound();
            }

            return View(courseWithStudents);
        }


        [HttpGet]
        public IActionResult Email(int id, int studentId)
        {

            var targetCourse = courses.CoursesDbSet.Find(id);

            var targetStudent = courses.StudentsDbSet.Find(studentId);

            if (targetCourse == null || targetStudent == null)
            {
                return NotFound();
            }

            // Pass data to the view
            ViewBag.CourseId = targetCourse.CourseId;
            ViewBag.CourseName = targetCourse.Name;
            ViewBag.StudentId = targetStudent.StudentId;
            ViewBag.StudentName = targetStudent.StudentName;

            return View();
        }



        [HttpPost]
        public IActionResult Add(Courses c)
        {

            if (ModelState.IsValid)
            {
                courses.CoursesDbSet.Add(c);
                courses.SaveChanges();

                return RedirectToAction("Manage", new { id = c.CourseId });
            }

            return View(c);
        }


        [HttpPost]
        public IActionResult Edit(Courses updatedCourse)
        {
            if (ModelState.IsValid)
            {
                var existingCourse = courses.CoursesDbSet.Find(updatedCourse.CourseId);

                if (existingCourse == null)
                {
                    return NotFound();
                }
                existingCourse.Name = updatedCourse.Name;
                existingCourse.Instructor = updatedCourse.Instructor;
                existingCourse.StartDate = updatedCourse.StartDate;

                courses.SaveChanges();

                return RedirectToAction("Manage", new { id = existingCourse.CourseId });
            }

            return View(updatedCourse);
        }


        [HttpPost]
        public IActionResult Manage(int id, string studentName, string email, string sendEmail)
        {
            var courseWithStudents = courses.CoursesDbSet
                .Include(c => c.Students)
                .FirstOrDefault(c => c.CourseId == id);

            if (courseWithStudents == null)
            {
                return NotFound();
            }

            if (!string.IsNullOrEmpty(studentName) && !string.IsNullOrEmpty(email))
            {
                var existingStudent = courses.StudentsDbSet.FirstOrDefault(s => s.CourseId == id && s.Email == email);

                if (existingStudent == null)
                {
                    var newStudent = new Student
                    {
                        StudentName = studentName,
                        Email = email,
                        CourseId = id,
                        Status = EnrollmentStatus.ConfirmationMessageNotSent
                    };

                    courses.StudentsDbSet.Add(newStudent);
                    courses.SaveChanges();
                }

            }

            if (!string.IsNullOrEmpty(sendEmail))
            {
                foreach (var student in courseWithStudents.Students.Where(s => s.Status == EnrollmentStatus.ConfirmationMessageNotSent))
                {
                    SendEmail(student.Email, courseWithStudents, student.StudentId, courses);

                    student.Status = EnrollmentStatus.ConfirmationMessageSent;
                }

                courses.SaveChanges();
            }

            return RedirectToAction("Manage", new { id });
        }


        private void SendEmail(string recipientEmail, Courses course, int studentId, CoursesDbContext dbContext)
        {
            try
            {
                var fromAddress = new MailAddress("nickturlea@gmail.com", "Your Name");
                var toAddress = new MailAddress(recipientEmail, "Recipient Name");
                const string fromAppPassword = "vloypvlgegdkrzjx";
                const string subject = "Invitation to Course Enrollment";

                var body = $"Dear Student,\n\nYou are invited to enroll in the course:\n\n";
                body += $"Course Name: {course.Name}\n";
                body += $"Instructor: {course.Instructor}\n";
                body += $"StartDate: {course.StartDate}\n\n";
                body += $"RoomNumber: {course.RoomNumber}\n\n";
                body += "To confirm your enrollment, please click the following link:\n";
                body += $"<a href='http://localhost:5020/Course/Email/{course.CourseId}?studentId={studentId}'>Confirm Enrollment</a>\n\n";
                body += "Thank you for choosing our course!\n";

                var smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(fromAddress.Address, fromAppPassword)
                };

                using (var message = new MailMessage(fromAddress, toAddress)
                {
                    Subject = subject,
                    Body = body,
                    IsBodyHtml = true
                })
                {
                    smtp.Send(message);
                }
                var student = dbContext.StudentsDbSet.FirstOrDefault(s => s.CourseId == course.CourseId && s.StudentId == studentId);
                if (student != null)
                {
                    student.Status = EnrollmentStatus.ConfirmationMessageSent;
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {
            }
        }

        [HttpPost]
        public IActionResult Email(int courseId, int studentId, bool enroll)
        {
            var student = courses.StudentsDbSet.FirstOrDefault(s => s.CourseId == courseId && s.StudentId == studentId);

            if (student != null)
            {
                student.Status = enroll ? EnrollmentStatus.EnrollmentConfirmed : EnrollmentStatus.EnrollmentDeclined;

                courses.SaveChanges();
            }

            return RedirectToAction("ThankYou");
        }


        public IActionResult ThankYou()
        {
            return View();
        }

    }
}




